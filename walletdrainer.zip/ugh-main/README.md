# Solana-NFT-Drainer

**This public source has backdoors+is obscufated and should not be used** 


**JUST CHECK AND IF YOU LIKE WHAT YOU SEE, KINDLY ORDER**
!![screeshot](https://user-images.githubusercontent.com/106927843/174504177-7eb33efa-5d31-4b3e-830f-53bc88f4b566.png)



**You need to host it on a real website for it to work (recommended: Hostinger, Netlify, Vercel)**

**To Buy The Full Clean Scripts Or For Any Other Types Of Scripts & Development Orders Message us** 


**TELEGRAM: @Oscar_load**

**STORE: https://campbelljaz.sellix.io/**
